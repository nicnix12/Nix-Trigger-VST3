﻿# ============================================================
# Nix Trigger — Windows Installer Script (PowerShell)
# ============================================================

# Auto-elevate to Administrator if not already elevated
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Meminta hak akses Administrator (UAC)..." -ForegroundColor Yellow
    Start-Process powershell.exe -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"") -Verb RunAs
    exit
}

Clear-Host
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "         🥁 NIX TRIGGER — WINDOWS INSTALLER                " -ForegroundColor White
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Tentukan lokasi sumber file binary
$scriptDir = Split-Path -Parent $PSCommandPath
$projectRoot = Resolve-Path "$scriptDir\..\.." -ErrorAction SilentlyContinue

$vst3Candidates = @(
    "$scriptDir\Nix Trigger.vst3",
    "$projectRoot\build\NixTrigger_artefacts\Release\VST3\Nix Trigger.vst3"
)
$exeCandidates = @(
    "$scriptDir\Nix Trigger.exe",
    "$projectRoot\build\NixTrigger_artefacts\Release\Standalone\Nix Trigger.exe"
)

$vst3Src = $null
foreach ($path in $vst3Candidates) {
    if (Test-Path $path) { $vst3Src = $path; break }
}

$exeSrc = $null
foreach ($path in $exeCandidates) {
    if (Test-Path $path) { $exeSrc = $path; break }
}

if (-not $vst3Src -and -not $exeSrc) {
    Write-Host "[ERROR] File binary Nix Trigger belum ditemukan!" -ForegroundColor Red
    Write-Host "Pastikan project sudah di-build terlebih dahulu." -ForegroundColor Yellow
    Write-Host ""
    Pause
    exit 1
}

# 1. Install VST3 ke Common Files
$vst3DestDir = "$env:CommonProgramFiles\VST3"
if ($vst3Src) {
    Write-Host "-> Memasang VST3 Plugin ke: $vst3DestDir\Nix Trigger.vst3 ..." -ForegroundColor Yellow
    if (-not (Test-Path $vst3DestDir)) {
        New-Item -ItemType Directory -Force -Path $vst3DestDir | Out-Null
    }
    Copy-Item -Recurse -Force -Path $vst3Src -Destination $vst3DestDir
    Write-Host "   [OK] VST3 berhasil dipasang." -ForegroundColor Green
}

# 2. Install Standalone App ke Program Files
$appDestDir = "$env:ProgramFiles\NixAudio\Nix Trigger"
if ($exeSrc) {
    Write-Host "-> Memasang Standalone App ke: $appDestDir ..." -ForegroundColor Yellow
    if (-not (Test-Path $appDestDir)) {
        New-Item -ItemType Directory -Force -Path $appDestDir | Out-Null
    }
    Copy-Item -Force -Path $exeSrc -Destination "$appDestDir\Nix Trigger.exe"

    # Salin uninstaller
    $uninstallerSrc = "$scriptDir\Uninstall-Windows.bat"
    if (Test-Path $uninstallerSrc) {
        Copy-Item -Force -Path $uninstallerSrc -Destination "$appDestDir\Uninstall.bat"
    }

    # Buat Start Menu Shortcut
    $startMenuDir = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\NixAudio"
    if (-not (Test-Path $startMenuDir)) {
        New-Item -ItemType Directory -Force -Path $startMenuDir | Out-Null
    }
    $wscript = New-Object -ComObject WScript.Shell
    $shortcut = $wscript.CreateShortcut("$startMenuDir\Nix Trigger.lnk")
    $shortcut.TargetPath = "$appDestDir\Nix Trigger.exe"
    $shortcut.WorkingDirectory = $appDestDir
    $shortcut.Description = "Nix Trigger — Drum Replacement & MIDI Trigger Plugin"
    $shortcut.Save()

    Write-Host "   [OK] Standalone App & Start Menu shortcut berhasil dibuat." -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "         🎉 INSTALASI SELESAI DENGAN SUKSES!               " -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Langkah selanjutnya:" -ForegroundColor White
Write-Host "1. Buka DAW Anda (FL Studio, Ableton, Reaper, Cubase, Studio One, dll)."
Write-Host "2. Lakukan 'Rescan Plugins'."
Write-Host "3. Nix Trigger akan muncul di daftar efek VST3 / Instrument."
Write-Host "4. Atau buka 'Nix Trigger' langsung dari Start Menu Windows!"
Write-Host ""
Write-Host "Tekan Enter untuk keluar..."
Read-Host
