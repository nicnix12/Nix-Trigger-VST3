﻿============================================================
              NIX TRIGGER v1.0.0 (WINDOWS x64)
============================================================

CARA INSTALL:
1. Klik kanan pada file "Install-Windows.bat" lalu pilih "Run as administrator"
   (atau cukup double-click).
2. Installer akan otomatis memasang:
   - VST3 Plugin ke folder sistem: C:\Program Files\Common Files\VST3\
   - Standalone Application ke: C:\Program Files\NixAudio\Nix Trigger\
   - Shortcut aplikasi di Start Menu Windows
3. Buka DAW Anda (FL Studio, Ableton, Reaper, Cubase, dll) lalu Rescan Plugins!

CARA UNINSTALL:
Jalankan "Uninstall-Windows.bat" jika ingin menghapus plugin ini.
============================================================
