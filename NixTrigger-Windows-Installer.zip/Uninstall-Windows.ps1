﻿# ============================================================
# Nix Trigger — Windows Uninstaller Script (PowerShell)
# ============================================================

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Meminta hak akses Administrator (UAC)..." -ForegroundColor Yellow
    Start-Process powershell.exe -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"") -Verb RunAs
    exit
}

Clear-Host
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "         🗑️ NIX TRIGGER — WINDOWS UNINSTALLER               " -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$vst3Target = "$env:CommonProgramFiles\VST3\Nix Trigger.vst3"
$appTarget  = "$env:ProgramFiles\NixAudio\Nix Trigger"
$shortcut   = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\NixAudio"

if (Test-Path $vst3Target) {
    Remove-Item -Recurse -Force $vst3Target
    Write-Host "-> Menghapus VST3 plugin..." -ForegroundColor Green
}

if (Test-Path $appTarget) {
    Remove-Item -Recurse -Force $appTarget
    Write-Host "-> Menghapus Standalone application..." -ForegroundColor Green
}

if (Test-Path $shortcut) {
    Remove-Item -Recurse -Force $shortcut
    Write-Host "-> Menghapus Start Menu shortcut..." -ForegroundColor Green
}

Write-Host ""
Write-Host "Nix Trigger telah berhasil di-uninstall dari komputer Anda." -ForegroundColor Cyan
Write-Host "Tekan Enter untuk keluar..."
Read-Host
